
import mysql.connector

# Connect to MySQL database
cnx = mysql.connector.connect(
    host='localhost',
    user='root',
    password='123456abc'
)

# Create database
def create_database(cursor):
    try:
        cursor.execute("CREATE DATABASE mydatabase")
        print("Database created successfully")
    except mysql.connector.Error as err:
        print(f"Failed creating database: {err}")

# Create table
def create_table(cursor):
    try:
        cursor.execute("USE mydatabase")
        cursor.execute("CREATE TABLE customers (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255), email VARCHAR(255))")
        print("Table created successfully")
    except mysql.connector.Error as err:
        print(f"Failed creating table: {err}")

# Insert data
def insert_data(cursor):
    try:
        cursor.execute("USE mydatabase")
        sql = "INSERT INTO customers (name, email) VALUES (%s, %s)"
        values = [
            ("John Doe", "john@example.com"),
            ("Jane Smith", "jane@example.com"),
            ("Bob Johnson", "bob@example.com")
        ]
        cursor.executemany(sql, values)
        cnx.commit()
        print("Data inserted successfully")
    except mysql.connector.Error as err:
        print(f"Failed inserting data: {err}")

# Select data
def select_data(cursor):
    try:
        cursor.execute("USE mydatabase")
        cursor.execute("SELECT * FROM customers")
        result = cursor.fetchall()
        for row in result:
            print(row)
    except mysql.connector.Error as err:
        print(f"Failed selecting data: {err}")

# Create database, table, insert data, and select data
cursor = cnx.cursor()
create_database(cursor)
create_table(cursor)
insert_data(cursor)
select_data(cursor)

# Close database connection
cnx.close()